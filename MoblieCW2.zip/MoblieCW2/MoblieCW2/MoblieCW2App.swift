//
//  MoblieCW2App.swift
//  MoblieCW2 w1685308
//
//  Created by Ahmed Mohamed on 28/04/2022.
//

import SwiftUI

@main
struct MoblieCW2App: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
