//
//  ContentView.swift
//  MoblieCW2 w1685308
//
//  Created by Ahmed Mohamed on 28/04/2022.
//

import SDWebImageSwiftUI
import SwiftUI
import MapKit

struct ContentView: View {
    @State private var selection: String? = nil
    @State private var location = ""
    @State var weatherForView:Welcome?
    var body: some View {
        NavigationView {
                VStack(alignment: .center, spacing: 30) {
                    HStack {
                        TextField("Enter Location", text: $location)
                            .textFieldStyle(RoundedBorderTextFieldStyle())
                        Button {
                            getWeather()
                            getHumidity()
                        } label: {
                            Image(systemName: "magnifyingglass.circle.fill")
                                .font(.title3)
                        }
                    }

                    HStack(spacing: 20){
                        Image("temp")
                            .resizable()
                            .frame(width: 32.0, height: 32.0)
                        Text(weatherForView?.main.temp.description ?? "Temperature")
                    }
                    
                    
                    HStack(spacing: 20){
                        Image("humidity")
                            .resizable()
                            .frame(width: 32.0, height: 32.0)
                        Text(weatherForView?.main.humidity.description ?? "Humidity")
                    }
                    
                    NavigationLink("Detailed Weather", destination: DeatiledWeather())
                    
                    NavigationLink("5 Day Forecast", destination: FiveDayForecast())
                    
                }
        }
        .padding(.horizontal)
        .navigationTitle("Mobile Weather")
        
    }
    func getWeather()
    {
        let url = setLocationStringForWeather(location: location)
        getCurrentWeather(url: url, completion: {_ in
            weatherForView = weather})
        
    }
    func getHumidity()
    {
        let url = setLocationStringForWeather(location: location)
        getCurrentWeather2(url: url, completion: {_ in
            weatherForView = weather})
    }
}


struct DeatiledWeather: View {
    @State private var location = ""
    @State var weatherForView:Welcome?
    var body: some View {
        
        VStack(spacing: 30) {
            
            HStack {
                TextField("Enter Location", text: $location)
                    .textFieldStyle(RoundedBorderTextFieldStyle())
                Button {
                    getWeather()
                } label: {
                    Image(systemName: "magnifyingglass.circle.fill")
                        .font(.title3)
                }
            }
            

            HStack(alignment: .center) {
                WebImage(url: weatherIconURL)
            }
            HStack(spacing: 20){
                Image("temp")
                    .resizable()
                    .frame(width: 32.0, height: 32.0)
                Text(weatherForView?.main.temp.description ?? "Temperature")
            }
            
            HStack(spacing: 20){
                Image("humidity")
                    .resizable()
                    .frame(width: 30.0, height: 32.0)
                Text(weatherForView?.main.humidity.description ?? "Humidity")
                    
            }
            
            HStack(spacing: 20){
                Image("pressure")
                    .resizable()
                    .frame(width: 32.0, height: 32.0)
                Text(weatherForView?.main.pressure.description ?? "Pressure")
            }
            
            HStack(spacing: 20){
                Image("windSpeed")
                    .resizable()
                    .frame(width: 32.0, height: 32.0)
                Text(weatherForView?.wind.speed.description ?? "Wind Speed")
            }
            
        }
        .padding(.horizontal)
        .navigationBarTitle("Detailed Weather")
        Text (location)
            .fontWeight(.bold)
            .font(.title2)
        
    }
    func getWeather()
    {
        let url = setLocationStringForWeather(location: location)
        getCurrentWeather(url: url, completion: {_ in
            weatherForView = weather})
        
    }
}
struct FiveDayForecast: View {

    var body: some View {
        
        NavigationView {
            Text("5 Day View")
        }.padding(.horizontal)
            .navigationBarTitle("Detailed Weather")
            Text (location)
                .fontWeight(.bold)
                .font(.title2)
}
}

struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        ContentView()
    }
}

