//
// WeatherModel.swift
//  MoblieCW2 w1685308
//
//  Created by Ahmed Mohamed on 28/04/2022.
//

//   let welcome = try? newJSONDecoder().decode(Welcome.self, from: jsonData)
import CoreLocation
import Foundation

// MARK: - Welcome
struct Welcome: Codable {
    let coord: Coord
    let weather: [Weather]
    let base: String
    let main: Main
    let visibility: Int
    let wind: Wind
    let clouds: Clouds
    let dt: Int
    let sys: Sys
    let timezone, id: Int
    let name: String
    let cod: Int
}

// MARK: - Clouds
struct Clouds: Codable {
    let all: Int
}

// MARK: - Coord
struct Coord: Codable {
    let lon, lat: Double
}

// MARK: - Main
struct Main: Codable {
    let temp, feelsLike, tempMin, tempMax: Double
    let pressure, humidity: Int

    enum CodingKeys: String, CodingKey {
        case temp
        case feelsLike = "feels_like"
        case tempMin = "temp_min"
        case tempMax = "temp_max"
        case pressure, humidity
    }
}

// MARK: - Sys
struct Sys: Codable {
    let type, id: Int
    let country: String
    let sunrise, sunset: Int
}

// MARK: - Weather
struct Weather: Codable {
    let id: Int
    let main, weatherDescription : String
    let icon: String

    enum CodingKeys: String, CodingKey {
        case id, main
        case weatherDescription = "description"
        case icon
    }
}

// MARK: - Wind
struct Wind: Codable {
    let speed: Double
    let deg: Int
}


var weather:Welcome?

func getCurrentWeather(url:String, completion: @escaping (Welcome)->())
{
    let session = URLSession(configuration: .default)
    session.dataTask(with:URL(string:url)!) {(data, _, err) in
        if err != nil {
            print(err!.localizedDescription)
            return
        }
        DispatchQueue.main.async{
            do {
                weather = try JSONDecoder().decode(Welcome.self, from:data!)
                print("Temp is \(weather?.main.temp)")
                completion(weather!)
            }
            catch{
                
                print(error)
            }
        }
    }.resume()
    
}


func getCurrentWeather2(url:String, completion: @escaping (Welcome)->())
{
    let session = URLSession(configuration: .default)
    session.dataTask(with:URL(string:url)!) {(data, _, err) in
        if err != nil {
            print(err!.localizedDescription)
            return
        }
        DispatchQueue.main.async{
            do {
                weather = try JSONDecoder().decode(Welcome.self, from:data!)
                print("Temp is \(weather?.main.humidity)")
                completion(weather!)
            }
            catch{
                
                print(error)
            }
        }
    }.resume()
    
}
let apiKey:String = "a760e7164b27ea4d1b263726928606f0"
var location: String = ""


func setLocationStringForWeather(location: String)->String
{
    return
        "https://api.openweathermap.org/data/2.5/weather?q=\(location)&appid=\(apiKey)&units=metric"
}


var weatherIconURL: URL {
    let urlString =  "https://openweathermap.org/img/wn/\(weather?.weather[0].icon ?? (""))@2x.png"
    return URL(string: urlString)!
}

//var weather:Welcome?
//
//var weatherIconURL: URL {
//    let urlString =  "https://openweathermap.org/img/wn/\(Welcome.weather[0].icon)@2x.png"
//    return URL(string: urlString)!
//}
////let url = setLocationStringForWeather(location: "London")
//getCurrentWeather(url: url,completion:{_ in
//    print("completed")})
